import LoginForm from "../props/LoginForm";
import "./Login.css";

export default function Login() {
	return (
		<div className="login-container">
			<LoginForm />
		</div>
	);
}